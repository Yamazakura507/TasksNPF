﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskThree.Model;

namespace TaskThree
{
    public partial class Form1 : Form
    {
        BindingList<Table> Tables = new BindingList<Table>() { AllowEdit = true, AllowNew = true, AllowRemove = true };
        SqlConnection Connection = null;
        SqlCommand command = null;
        bool IsClosedDataRead = false;

        public Form1()
        {
            InitializeComponent();

            dataGridView1.DataSource = Tables;
        }

        private void FormOnLoad(object sender, EventArgs e)
        {
            string[] sqlConection = Properties.Settings.Default.TestDBConnectionString.Split(';');

            for (int i = 0; i < sqlConection.Length; i++)
            {
                sqlConection[i] = sqlConection[i].Split('=')[1].Trim();
            }

            ServerTextBox.Text = sqlConection[0];
            DataBaseTextBox.Text = sqlConection[1];

            if (sqlConection.Length > 3)
            {
                checkWindCheckBox.Checked = false;
                LoginTextBox.Text = sqlConection[2];
                PasswordTextBox.Text = sqlConection[3];
            }
            else
            {
                checkWindCheckBox.Checked = true;
            }
        }

        private void CheckBoxOnCheckedChanged(object sender, EventArgs e)
        {
            labelLogin.Visible = labelPassword.Visible = LoginTextBox.Visible = PasswordTextBox.Visible = !checkWindCheckBox.Checked;
        }

        private void StartButtonOnClick(object sender, EventArgs e)
        {
            try
            {
                string[] parameters = new string[4];
                parameters = Properties.Settings.Default.TestDBConnectionString.Split(';');
                parameters[0] = parameters[0].Split('=')[0] + "= " + ServerTextBox.Text;
                parameters[1] = parameters[1].Split('=')[0] + "= " + DataBaseTextBox.Text;

                if (checkWindCheckBox.Checked)
                {
                    parameters[2] = "Integrated Security = True";
                }
                else
                {
                    parameters[2] = $"User Id = {LoginTextBox.Text}";
                    parameters[3] = $"Password = {PasswordTextBox.Text}";
                }

                Properties.Settings.Default.TestDBConnectionString = String.Join(";", parameters);
                Properties.Settings.Default.Save();

                SqlDependency.Start(Properties.Settings.Default.TestDBConnectionString);
                Connection = new SqlConnection(Properties.Settings.Default.TestDBConnectionString);
                Connection.Open();

                SqlClientPermission perm = new SqlClientPermission(PermissionState.Unrestricted);
                perm.Demand();

                SomeMethod();

                StopButton.Enabled = true;
                ServerTextBox.Enabled = DataBaseTextBox.Enabled = checkWindCheckBox.Enabled = LoginTextBox.Enabled = PasswordTextBox.Enabled = StartButton.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SomeMethod()
        {
            try
            {
                if (command == null)
                {
                    command = new SqlCommand("SELECT [Id],[Flag],[Data] FROM [dbo].[Table]", Connection);
                }
                else
                {
                    command.Notification = null;
                }

                SqlDependency dependency = new SqlDependency(command);

                IsClosedDataRead = false;

                int countRow = (int)new SqlCommand("SELECT COUNT(*) FROM [dbo].[Table]", Connection).ExecuteScalar();

                if (countRow == 0)
                {
                    OnDependencyChange(null, null);
                }

                Tables.Clear();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Tables.Add(Table.Get(reader));

                        if (countRow < 2)
                        {
                            dependency.OnChange += OnDependencyChange;
                        }

                        countRow--;
                    }
                }

                IsClosedDataRead = true;
            }
            catch (InvalidOperationException)
            {
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void OnDependencyChange(object sender, SqlNotificationEventArgs e)
        {
            if (sender is null)
            {
                await Task.Delay(100);
                SomeMethod();
                return;
            }

            while (!IsClosedDataRead)
            {
                await Task.Delay(100);
            }

            SqlDependency dependency = (SqlDependency)sender;
            dependency.OnChange -= OnDependencyChange;
            await Task.Delay(200);
            SomeMethod();
        }

        private void StopButtonOnClick(object sender, EventArgs e)
        {
            Connection.Close();

            ServerTextBox.Enabled = DataBaseTextBox.Enabled = checkWindCheckBox.Enabled = LoginTextBox.Enabled = PasswordTextBox.Enabled = StopButton.Enabled = true;
            StartButton.Enabled = true;
        }

        private void Form1OnFormClosing(object sender, FormClosingEventArgs e)
        {
            SqlDependency.Stop(Properties.Settings.Default.TestDBConnectionString);
        }
    }
}
