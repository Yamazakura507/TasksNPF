﻿using System.ComponentModel;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;

namespace TaskThree.Model
{
    public class Table : INotifyPropertyChanged
    {
        private int id { get; set; }
        private bool flag { get; set; }
        private string data { get; set; }

        public int Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public bool Flag
        {
            get
            {
                return flag;
            }
            set
            {
                flag = value;
                NotifyPropertyChanged();
            }
        }

        public string Data
        {
            get
            {
                return data;
            }
            set
            {
                data = value;
                NotifyPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public static Table Get(SqlDataReader reader)
        {
            return new Table()
            {
                Id = reader.GetInt32(0),
                Flag = reader.GetBoolean(1),
                Data = reader.GetString(2)
            };
        }
    }
}
